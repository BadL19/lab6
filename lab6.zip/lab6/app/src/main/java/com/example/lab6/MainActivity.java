package com.example.bhuvan.helloworld;


import android.os.Bundle;

public class DisplayCat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_cat);

    }
}